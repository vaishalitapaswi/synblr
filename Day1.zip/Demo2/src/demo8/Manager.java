package demo8;

import java.util.List;

public interface Manager<T, T1> {
	public List<T> getlist();
	public default void create(T t1){
	//	System.out.println("in create of Manager");
		this.getlist().add(t1);
		
	}
	// design 1  => DeptManager is writing code
	public void delete(T1 pk);
}
