
interface SimpleInterface {
	public static void m1(){
		System.out.println("in m1 of SimpleInterface");
	}
	void m2();
}
class SimpleImpl implements SimpleInterface{

	@Override
	public void m2() {
		System.out.println("in m2 of SimpleImpl");
	}
	
}
public class Lab3  {

	public static void main(String[] args) {
		SimpleImpl impl = new SimpleImpl();
		
		impl.m2();
		
		SimpleInterface.m1();
	}

}
