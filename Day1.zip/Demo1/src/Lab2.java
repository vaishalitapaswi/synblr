interface Operation
{
	public int mycode(int i, int j);
}
class Calc2
{
	public int execute(int no1, int no2, Operation op){
		return op.mycode(no1, no2);
	}
}
public class Lab2 {
	public static void main(String[] args) {
		Calc2 c2 = new Calc2();
		System.out.println("Sum = " + c2.execute(10,30,(x,y)->x+y));
		System.out.println("Sub = " + c2.execute(10,30,(x,y)->x-y));
		System.out.println("Mult = " + c2.execute(10,30,(x,y)->x*y));
		System.out.println("Division = " + c2.execute(100,30,(x,y)->x-y));
	}
	
}
