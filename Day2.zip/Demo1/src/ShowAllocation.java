import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ShowAllocation {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a number to continue");
		scanner.nextInt();
		List<String> l1 = new ArrayList<>();
		for (int k = 0; k < 9000; k++) {
		
			for (int i = 0; i < 900; i++) {
				l1.add("str" + i);
			}
			if ( k==998)
				System.gc();
			Thread.sleep(10);
		}
	}

}
