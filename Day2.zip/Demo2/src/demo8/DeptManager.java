package demo8;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;

public class DeptManager implements Manager<Dept, Integer>{
	private List<Dept> list = new ArrayList<>();

	@Override
	public List<Dept> getlist() {
		return list;
	}
	//Option 1
	/*public void delete(Integer pk){
		for (int i = 0;i< list.size();i++) 
		{
			if (list.get(i).getDeptno() == pk) {
					list.remove(list.get(i));
					break;
			}
		}
	}*/
	public void delete(Predicate<Dept> pred){
			list.removeIf(pred);
	}
	
	
/*	public void delete(int deptno){
		for (int i = 0;i< list.size();i++) 
		{
			if (list.get(i).getDeptno() == deptno) {
					list.remove(list.get(i));
					break;
			}
		}
	}
	public void update(Dept newDept) {
		for (int i = 0;i< list.size();i++) 
		{
			if (list.get(i).getDeptno() == newDept.getDeptno()) {
				list.set(i,newDept);
				System.out.println("Update " + newDept);
				break;
			}
		}
	}
	*/

	public static void main(String[] args) {
		DeptManager mgr = new DeptManager();
		for(int i =1;i<=10;i++){
			Dept d = new Dept();
			d.setDeptno(i);
			d.setDname("Nameof"+i);
			if ((i % 2) ==0)
				d.setLoc("BLR");
			else
				d.setLoc("Hyd");
			mgr.create(d);
		}
		mgr.delete(d->d.getDeptno()==5);
		
	//	mgr.delete(5);
		
		/*Dept d= new Dept(2, "HR","Pnq");
		mgr.update(d);*/
		for (Dept  dept : mgr.getlist()) {
			System.out.println(dept);
		}
	}
	
}
