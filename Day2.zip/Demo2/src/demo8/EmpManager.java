package demo8;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;

public class EmpManager implements Manager<Emp, Integer> {
	private List<Emp> list = new ArrayList<>();

	@Override
	public List<Emp> getlist() {
		return list;
	}
	@Override
	public void delete(Predicate<Emp> pred) {
		list.removeIf(pred);
	}
	
	/*
	public void delete(Integer pk){
		for (int i = 0;i< list.size();i++) 
		{
			if (list.get(i).getEmpno() == pk) {
					list.remove(list.get(i));
					break;
			}
		}
	}*/
	/*	public void update(Emp newEmp) {
		for (int i = 0;i< list.size();i++) 
		{
			if (list.get(i).getEmpno() == newEmp.getEmpno()) {
				list.set(i,newEmp);
				System.out.println("Update " + newEmp);
				break;
			}
		}
	}
*/
	public static void main(String[] args) {
		EmpManager mgr = new EmpManager();
		for(int i =1;i<=10;i++){
			Emp e = new Emp();
			e.setEmpno(i);
			e.setEname("Nameof"+i);
			e.setSalary(i*1000);
			mgr.create(e);
		}
		
	mgr.delete(e->e.getEmpno()==5);
	
	
	/*	Emp d= new Emp(2, "Vaishali",2222.22);
		mgr.update(d);
	*/
		for (Emp  emp : mgr.getlist()) {
			System.out.println(emp);
		}
	}




}
