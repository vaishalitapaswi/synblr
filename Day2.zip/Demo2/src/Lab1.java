

interface MyInterface {
	default void m1(){
		System.out.println("in m1 method of MyInterface");
	}

	void m2();
}

class MyImpl implements MyInterface {
	public void m1(){
		System.out.println("in m1 method of MyImpl");
	}
public	void m2() {
	System.out.println("MyIMple - m2 invoked ");
	}

}

public class Lab1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyImpl my = new MyImpl();
		my.m1();
		my.m2();
	}

}
