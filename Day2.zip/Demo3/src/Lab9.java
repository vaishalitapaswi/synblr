import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Scanner;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Lab9 {

	public static void main(String[] args) {
		List<Emp> list = EmpManager.create();
		list.forEach(System.out::println);
		System.out.println("\n");
		Map<String, List<Emp>> byDept
	         = list.stream()
	                    .collect(Collectors.groupingBy(e -> e.getDept()));
	    byDept.forEach((key,value)-> {
	      System.out.println(key  + " ="  );
	    	System.out.println(value.size());
	    }); 
	    Map<String, Long> countbyDept
        = list.stream().collect
        	(Collectors.groupingBy(Emp::getDept,Collectors.counting()));
	   
	    System.out.println(countbyDept);
   
		  Map<String,Double> salbydept
		  	= list.stream().collect
		  		(Collectors.groupingBy
		  				(Emp::getDept, Collectors.summingDouble(Emp::getSalary)));
		  	System.out.println(salbydept);
		 
		  	salbydept
		  	= list.stream().collect
		  		(Collectors.groupingBy
		  				((Emp e)->e.getDept(),Collectors.summingDouble((Emp e)-> e.getSalary())));
		  	System.out.println(salbydept);
	}
}
