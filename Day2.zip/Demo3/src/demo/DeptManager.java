package demo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

public class DeptManager {
	private List<Dept> list = new ArrayList<>();

	public void create(Dept d){
		list.add(d);
	}
	public List<Dept> list(){
		return this.list;
	}
	
	public void delete(Predicate<Dept> pred){
		this.list.removeIf(pred);
	}
	public void update(Dept newDept) {
		//Option 1
/*		this.list.replaceAll((d)->
	{
		if (d.getDeptno() == newDept.getDeptno())
			return newDept;
		else
			return d;
	});*/
		//Option 2
		Optional<Dept> odept =
				this.list.stream().filter((d)->d.getDeptno()==newDept.getDeptno()).findFirst();
		if (odept.isPresent())
		{
				Dept d1= odept.get();
				d1.setDname(newDept.getDname());
				d1.setLoc(newDept.getLoc());
		}
	}

	public static void main(String[] args) {
		DeptManager mgr = new DeptManager();
		for(int i =1;i<=10;i++){
			Dept d = new Dept();
			d.setDeptno(i);
			d.setDname("Nameof"+i);
			if ((i % 2) ==0)
				d.setLoc("BLR");
			else
				d.setLoc("Hyd");
			mgr.create(d);
		}
		mgr.list.forEach(System.out::println);
		System.out.println("after replacing");
		mgr.delete(d-> d.getDeptno()==3);
		mgr.delete(d->d.getLoc().equals("BLR"));
		Dept d= new Dept(2, "HR","Pnq");
		mgr.update(d);
		for (Dept  dept : mgr.list) {
			System.out.println(dept);
		}
	}
}
