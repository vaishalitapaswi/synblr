import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Lab7 {

	public static void main(String[] args) {
		List<Emp> list = EmpManager.create();
		//list.stream().filter(e->e.getEname().equals("Vanita")).forEach(System.out::println);
		//list.stream().filter(e->e.getSalary()>100).forEach(System.out::println);
/*		list.stream().filter(e->e.getSalary()>100).filter(e->e.getSalary()<200).forEach(System.out::println);
		
		System.out.println("\n\n\n");
		Predicate<Emp> pred = e-> e.getSalary()>100 && e.getSalary() <200;
		list.stream().filter(pred).forEach(System.out::println);
*/	
		list.stream().forEach(System.out::println);
		double sum = list.stream().mapToDouble(e->e.getSalary()).sum();
		System.out.println("Sum " + sum);
}
}
