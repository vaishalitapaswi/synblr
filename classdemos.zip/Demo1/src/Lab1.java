import java.util.Date;

public class Lab1 {
	public static void main(String[] args) {
	/*	Runnable helper =  () ->  System.out.println("Lab1 - Run method is invoked....");
		Thread t1 = new Thread(helper);
		t1.start();*/
		
		System.out.println("\n\nIn Main...");
		
		
		System.out.println(new Date());
	}
}
