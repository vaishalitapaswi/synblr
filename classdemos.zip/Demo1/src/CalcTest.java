@FunctionalInterface
interface Calc {
	public int sqr(int x);
}

public class CalcTest {

	public static void main(String[] args) {
	  Calc c = x -> x*x;
	  
	  System.out.println(c.sqr(10));	

	}

}
