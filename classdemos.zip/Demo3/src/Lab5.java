import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Lab5 {

	public static void main(String[] args) {
		List<String> list = Stream.of("Vaishali","Vanita","Anita","Surekha","Suman","amit").collect(Collectors.toList());
		System.out.println(list);
		List<String> sortedlist = list.stream().sorted().collect(Collectors.toList());
		System.out.println(sortedlist);
		sortedlist = list.stream().sorted((s1,s2)->s1.compareToIgnoreCase(s2)).collect(Collectors.toList());
		System.out.println(sortedlist);
		boolean exists= list.stream().anyMatch((x)->x.equals("Surekha"));
		System.out.println("Surekha exists is " + exists);
	}
}

