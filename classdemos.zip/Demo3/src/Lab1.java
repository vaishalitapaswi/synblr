import java.util.Arrays;
import java.util.stream.Stream;

public class Lab1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int intarr[] = {10,30,111,11,6};
		Stream.of(intarr).forEach((x)->System.out.println("first: " +x));
		Arrays.stream(intarr).forEach(System.out::println);
		System.out.println("\n\n");
		Arrays.stream(intarr).forEach(System.out::println);
	}

}
