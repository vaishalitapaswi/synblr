import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Lab8 {

	public static void main(String[] args) {
		String strarr[] ={"aa","bb","cc","dd","ee"};
		List<String> list = Stream.of(strarr).collect(Collectors.toList());
		list.stream().forEach(System.out::println);
		System.out.println("\n");
		Optional<String> stroption = list.stream().reduce((s1,s2)->s1+s2);
		System.out.println(stroption.get());
		
		Integer intarr[] ={10,20,5,40,50};
		Optional<Integer> intoption = Stream.of(intarr).reduce((s1,s2)->s1+s2);
		 
		System.out.println("Sum = " + intoption.get());
		
		 intoption = Stream.of(intarr).reduce((s1,s2)->s1*s2);
		 
		System.out.println("Product  = "+ intoption.get());
}
}
