import java.util.Arrays;
import java.util.stream.Stream;

public class Lab3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int intarr[] = {10,30,111,11,6};
		String strarr[] ={"Vaishali","vanita","Ankita","Anita","1l"};
		Arrays.stream(intarr).forEach(x->System.out.print("\t"+ x));
		System.out.println("\nSorted ...");
		Arrays.stream(intarr).sorted().forEach(x->System.out.print("\t"+ x));
		System.out.println("\nSorted String array...");
		Arrays.stream(strarr).sorted().forEach(x->System.out.print("\t"+ x));
		System.out.println();
		Arrays.stream(strarr).sorted().forEach(x->System.out.print("\t"+ x.length()));
		System.out.println();
		Arrays.stream(strarr)
			.map((str)->{
								return str.length();
							}).peek(x->System.out.println("in map.peek" + x))
			.sorted()
			.peek(x->System.out.println("in sorted.peek" + x))
	     	.forEach(x->System.out.println("\tinForeach"+ x));
	}

}
