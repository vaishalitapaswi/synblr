import java.util.ArrayList;
import java.util.List;

public class EmpManager {
	public static List<Emp> create(){
		List<Emp> list = new ArrayList<>();
		String names[] = {"Vaishali","Vanita","Anita","Surekha","Suman","amit","Imran"};
		String deptnames[] = {"HR","TRN","FIN"};
		for (int i = 1;i<=10;i++){
			Emp e1 = new Emp();
			e1.setEmpno(i);
			e1.setEname(names[i % names.length]);
			e1.setDept(deptnames[i% deptnames.length]);
			//e1.setSalary( i *(int) (Math.random() * 100));
			e1.setSalary(i*10);
			list.add(e1);
		}
		return list;
	}
}
