import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Lab4 {

	public static void main(String[] args) {
		List<Integer> list = new ArrayList<>();
		list.add(200); list.add(30);
		list.add(4000);list.add(500); list.add(1111);
		System.out.println("Sorted Data ");
		list.stream().sorted().forEach(System.out::println);
		
		Optional<Integer> optionalinteger = list.stream().min((n1,n2)-> Integer.compare(n1, n2));
		if (optionalinteger.isPresent())
				System.out.println(" Min = " + optionalinteger.get());
		IntStream intstr  = list.stream().mapToInt(x->x.intValue());
		System.out.println("Min = " + intstr.min());
		System.out.println("Max = " + list.stream().mapToInt(x->x.intValue()).max());
		System.out.println("Sum  = " + list.stream().mapToInt(x->x.intValue()).sum());
	}
}

