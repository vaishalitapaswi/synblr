import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Lab6 {

	public static void main(String[] args) {
		List<Emp> list = EmpManager.create();
		Scanner scanner = new Scanner(System.in);
		
//		list.stream().forEach(System.out::println);
	//	list.parallelStream().forEach(System.out::println);
		int skipcount = 0;
		int limitcount = 10;
		String str="";
		do {
			list.stream().skip(skipcount).limit(limitcount).forEach(System.out::println);
			System.out.println(" Prev/Next/Quit");
			 str = scanner.nextLine();
			if (str.equalsIgnoreCase("N"))
				skipcount+= limitcount;
			if (str.equalsIgnoreCase("P"))
				skipcount-= limitcount;
		
		}while(!str.equalsIgnoreCase("Q"));

	}
}

