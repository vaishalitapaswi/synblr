import java.util.Arrays;
import java.util.function.Function;
import java.util.function.IntBinaryOperator;
import java.util.function.UnaryOperator;
import java.util.stream.Stream;

public class Lab2 {

	public static void main(String[] args) {
		Function<Integer, Integer> sqr1 = (x)->x*x;
		System.out.println("SQR1 = " + sqr1.apply(10));
		UnaryOperator<Integer> sqr2 = (x)->x*x;
		System.out.println("SQR2 = " + sqr2.apply(10));
		Function<String,Integer> strlen = (x)->x.length();
		System.out.println("Strlength of aaa = " + strlen.apply("aaa"));
		System.out.println("Strlength of bbb = " + strlen.apply("aaa"));
		IntBinaryOperator add = (a,b)->a+b;
		System.out.println("Add(10,40) = " + add.applyAsInt(10, 40));
		
 	}

}
