package demo8;

import java.util.List;
import java.util.function.Predicate;

public interface Manager<T, T1> {
	public List<T> getlist();
	public default void create(T t1){
	//	System.out.println("in create of Manager");
		this.getlist().add(t1);
		
	}
	// design 1  => DeptManager is writing code
	//public void delete(T1 pk);
	// design 2  => Client will write code and DeptManager will execute it
	public void delete(Predicate<T> pred);
}
