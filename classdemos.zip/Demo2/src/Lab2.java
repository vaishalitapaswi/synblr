

interface MyInter1 {
	default void m1() {
		System.out.println("in m1 method of MyInter1");
	}

	void m2();
}

interface MyInter2 {
	default void m1() {
		System.out.println("in m1 method of MyInter2");
	}

	void m2();
}

class MyImpl1 implements MyInter1, MyInter2 {

	public void m2() {
		System.out.println("MyIMpl1 - m2 invoked ");
	}

	@Override
	public void m1() {
		// TODO Auto-generated method stub
		System.out.println("m1 of MyIMpl1");
	}
}

public class Lab2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyImpl my = new MyImpl();
		my.m1();
		my.m2();
	}

}
