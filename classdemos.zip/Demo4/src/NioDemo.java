import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class NioDemo {

	public static void main(String[] args) {
		long starttime = System.currentTimeMillis();
		File source = new File(args[0]);
		File destination = new File(args[1]);
		FileInputStream fis = null;
		FileOutputStream fos = null;
		FileChannel inputchannel = null;
		FileChannel outputchannel = null;
		try{
			fis = new FileInputStream(source);
			fos = new FileOutputStream(destination);
			inputchannel = fis.getChannel();
			outputchannel = fos.getChannel();
			ByteBuffer buffer = ByteBuffer.allocate(1024*1024);
			int i = 0;
			do {
				buffer.clear();
				i = inputchannel.read(buffer);
				buffer.flip();
				outputchannel.write(buffer);
			}while( i != -1);
			
		}catch(Exception e)
		{
			System.out.println("Exception " + e);
		}
		finally {
			try {
				fis.close();
				fos.close();
				inputchannel.close();
				outputchannel.close();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		}
		long endtime = System.currentTimeMillis();
		System.out.println(" Time taken  = " + (endtime- starttime)/1000 );
	}

}
