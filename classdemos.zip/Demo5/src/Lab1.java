import java.sql.Date;

public class Lab1 {

	public static void main(String[] args) {
		System.out.println("Hello World !!!");
		Date d1 = new Date(new java.util.Date().getTime());
		System.out.println("Date = " + d1);
	}

}

// javac Lab1.java 
// javac -profile compact1 Lab1.java 
//----> check messages for compact1 and compact2
