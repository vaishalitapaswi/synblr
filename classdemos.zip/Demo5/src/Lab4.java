import java.time.LocalDate;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class Lab4 {

	public static void main(String[] args) throws ScriptException {
		ScriptEngine engine = new ScriptEngineManager().getEngineByName("nashorn");
		 
		Object result = engine.eval("var greeting='hello world'; " +
		   "print(greeting); "  + "greeting");
		System.out.println(result);
		
		Object result1 = engine.eval("var n1=10; " +
				   "var n2 = 20;"  + "n1+n2");
				System.out.println(result1);
		
	
	}

}
