import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;

public class Lab3 {

	public static void main(String[] args) {
		LocalDate ld = LocalDate.of(2018, 6, 20);
		System.out.println(ld);

	}

}
