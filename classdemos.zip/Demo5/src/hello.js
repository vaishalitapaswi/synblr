print("HelloWorld form hello.js")
var add= function(n1, n2) {
        return n1+n2;
    };
add;
