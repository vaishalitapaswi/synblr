import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import com.sun.org.apache.bcel.internal.util.ClassPath;

public class Lab5 {

	public static void main(String[] args) throws Exception {
		ScriptEngineManager manager = new ScriptEngineManager();
		ScriptEngine engine = manager.getEngineByName("JavaScript");
		// read script file

		Object math = engine.eval(Files.newBufferedReader
				(Paths.get(Lab5.class.getResource("hello.js").toURI()), StandardCharsets.UTF_8));
		Invocable inv = (Invocable) engine;
		Object o = inv.invokeFunction("add", 1010,200);
		System.out.println(o);
		o = inv.invokeFunction("add", "Hello","World");
		System.out.println(o);
	}

}
